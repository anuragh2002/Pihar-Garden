// const searchInput = document.querySelector("[data-search]");

// searchInput.addEventListener("input", (e) => {
//   const value = e.target.value;
// });

// let users = [];

// users = data.map((user) => {});
// console.log(document.querySelector("[data-header]").textContent);
// S

// const searchInput = () => {
//   let filter = document.getElementById("search").value.toUpperCase();
//   console.log(filter);
//   let header = document.querySelectorAll("p#header");
//   for (let i = 0; i < header.length; i++) {
//     let heading = header[i].textContent || header[i].innerHTML;

//     if (heading.toUpperCase().indexOf(filter) > -1) {
//       header[i].style.display = "";
//     } else {
//       header[i].style.display = none;
//     }
//   }
// };

// searchInput();
const searchBar = document.getElementById("search");

searchBar.addEventListener("input", function () {
  const searchQuery = searchBar.value.toLowerCase();
  // const accordion = document.querySelectorAll(".accordion-body");
  const cards = document.querySelectorAll(".card");

  cards.forEach(function (card) {
    const cardHeading = card.querySelector(".card-heading");
    const cardText = cardHeading.textContent.toLowerCase();

    if (cardText.includes(searchQuery)) {
      card.style.display = "block";
    } else {
      card.style.display = "none";
    }

    console.log(cards);
  });
});
